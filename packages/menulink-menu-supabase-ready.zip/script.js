const SUPABASE_URL = 'https://snntyrevgtyjjwnsdsrj.supabase.co';
const SUPABASE_KEY = 'sb_publishable_CVsIAE1KndWtqYLcEjAEDg_YhCQfrmZ';

const fallbackMenu = [
  {id:'drip',name:'القهوة المقطرة',icon:'◌',items:[['V60 إثيوبي','قهوة زهرية بنكهة البرغموت والخوخ','22'],['V60 كولومبي','كراميل، كاكاو، وفواكه حمراء','21'],['كولد برو','استخلاص بارد لمدة 18 ساعة','20','الأكثر طلباً'],['كيمكس لشخصين','استخلاص نقي ومتوازن','34']]},
  {id:'espresso',name:'إسبريسو',icon:'●',items:[['إسبريسو','جرعة مركزة ومتوازنة','12'],['أمريكانو','إسبريسو وماء ساخن','14'],['كابتشينو','إسبريسو وحليب مبخر','18'],['فلات وايت','قوام مخملي ونكهة قهوة واضحة','19','مميز']]},
  {id:'matcha',name:'ماتشا',icon:'✦',items:[['ماتشا لاتيه','ماتشا يابانية مع الحليب','22'],['ماتشا فراولة','فراولة طازجة وماتشا كريمية','25','جديد'],['ماتشا جوز الهند','حليب جوز هند ولمسة فانيلا','24'],['ماتشا صافية','ماتشا وماء فقط','18']]},
  {id:'breakfast',name:'الفطور الصحي',icon:'☼',items:[['توست أفوكادو','أفوكادو، فيتا، وبيض مسلوق','29'],['جرانولا بول','زبادي يوناني، فواكه، وعسل','27'],['ساندويتش حلوم','حلوم مشوي وخضار طازجة','26'],['بيض تركي','لبنة، بيض، وزبدة بابريكا','31','اختيار الشيف']]},
  {id:'daily',name:'قهوة اليوم',icon:'◇',items:[['قهوة اليوم — صغير','اختيار يومي من محاصيلنا','10'],['قهوة اليوم — كبير','اختيار يومي من محاصيلنا','14'],['آيس كوفي اليوم','قهوة اليوم على الثلج','16'],['ترمس قهوة','يكفي 4 إلى 5 أشخاص','48']]},
  {id:'drinks',name:'المشروبات',icon:'≈',items:[['شاي خوخ مثلج','خوخ، شاي أسود، وليمون','18'],['ليمون نعناع','ليمون طازج ونعناع','17'],['موهيتو توت','توت مشكل وليمون','20'],['مياه غازية','زجاجة 330 مل','9']]},
  {id:'dessert',name:'الحلويات',icon:'♡',items:[['سان سباستيان','تشيز كيك مخبوزة يومياً','26','الأكثر طلباً'],['كيكة تمر','تمر وقرفة وصوص كراميل','24'],['كرواسون لوز','زبدة فرنسية وحشوة لوز','19'],['كوكي شوكولاتة','شوكولاتة داكنة وملح بحري','15']]},
  {id:'extras',name:'محاصيلنا والإضافات',icon:'＋',items:[['محصول إثيوبي 250 جم','مناسب للترشيح','65'],['محصول كولومبي 250 جم','متوازن وحلو','62'],['حليب بديل','شوفان أو جوز هند','4'],['نكهة إضافية','فانيلا، كراميل، بندق','3']]}
];

async function loadMenu() {
  const headers = { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` };
  const [categoriesResponse, itemsResponse] = await Promise.all([
    fetch(`${SUPABASE_URL}/rest/v1/menu_categories?select=id,name_ar,icon,sort_order&is_active=eq.true&order=sort_order.asc`, { headers }),
    fetch(`${SUPABASE_URL}/rest/v1/menu_items?select=category_id,name_ar,description_ar,price,badge_ar,sort_order&is_active=eq.true&order=sort_order.asc`, { headers })
  ]);

  if (!categoriesResponse.ok || !itemsResponse.ok) throw new Error('تعذر تحميل بيانات المنيو');

  const categories = await categoriesResponse.json();
  const items = await itemsResponse.json();
  return categories.map(category => ({
    id: category.id,
    name: category.name_ar,
    icon: category.icon,
    items: items
      .filter(item => item.category_id === category.id)
      .map(item => [item.name_ar, item.description_ar || '', Number(item.price).toString(), item.badge_ar || undefined])
  }));
}

function renderMenu(menu) {
  const categories = document.getElementById('categories');
  const sections = document.getElementById('menuSections');
  categories.innerHTML = '';
  sections.innerHTML = '';
  document.getElementById('sectionCount').textContent = `${menu.length} أقسام`;

  menu.forEach((section, index) => {
    const button = document.createElement('button');
    button.className = `category${index === 0 ? ' active' : ''}`;
    button.textContent = section.name;
    button.onclick = () => document.getElementById(section.id).scrollIntoView({ behavior: 'smooth' });
    categories.appendChild(button);

    const element = document.createElement('section');
    element.className = 'menu-section';
    element.id = section.id;
    element.innerHTML = `<div class="menu-heading"><h3>${section.name}</h3><span>${section.icon}</span></div><div class="items">${section.items.map(item => `<article class="item"><div><h4>${item[0]}</h4><p>${item[1]}</p>${item[3] ? `<span class="badge">${item[3]}</span>` : ''}</div><div class="price">${item[2]} ر.س</div></article>`).join('')}</div>`;
    sections.appendChild(element);
  });

  const buttons = [...document.querySelectorAll('.category')];
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const index = menu.findIndex(section => section.id === entry.target.id);
      buttons.forEach((button, buttonIndex) => button.classList.toggle('active', buttonIndex === index));
      buttons[index]?.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
    });
  }, { rootMargin: '-35% 0px -55% 0px' });
  document.querySelectorAll('.menu-section').forEach(section => observer.observe(section));
}

loadMenu().then(renderMenu).catch(error => {
  console.warn(error);
  renderMenu(fallbackMenu);
});

const toTop = document.getElementById('toTop');
window.addEventListener('scroll', () => toTop.classList.toggle('show', scrollY > 500));
toTop.onclick = () => scrollTo({ top: 0, behavior: 'smooth' });
document.getElementById('langButton').onclick = () => alert('يمكن إضافة النسخة الإنجليزية من لوحة الإدارة لاحقًا.');
